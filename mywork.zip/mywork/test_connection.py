import pyodbc
import sys
from datetime import datetime
import socket

def print_step(message):
    print(f"\n[{datetime.now().strftime('%H:%M:%S')}] {message}")

def test_port(host, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception as e:
        print(f"Error testing port: {str(e)}")
        return False

def test_connection():
    # Database configuration
    DB_CONFIG = {
        'driver': '{ODBC Driver 17 for SQL Server}',
        'server': 'localhost,1433',  # Using the port from docker-compose
        'database': 'HealthcareDB',  # Using the provided database name
        'username': 'sa',
        'password': 'YourStrong@Passw0rd',  # Using the password from docker-compose
        'trust_server_certificate': 'yes',
        'timeout': 30
    }

    try:
        # Step 1: Check if pyodbc is installed
        print_step("Checking pyodbc installation...")
        print(f"pyodbc version: {pyodbc.version}")
        print("✓ pyodbc is installed")

        # Step 2: List available drivers
        print_step("Checking available ODBC drivers...")
        drivers = pyodbc.drivers()
        print("Available drivers:")
        for driver in drivers:
            print(f"- {driver}")
        
        if not drivers:
            print("❌ No ODBC drivers found!")
            return False

        # Step 3: Test port availability
        print_step("Testing port availability...")
        host = 'localhost'
        port = 1433
        if test_port(host, port):
            print(f"✓ Port {port} is open on {host}")
        else:
            print(f"❌ Port {port} is closed on {host}")
            return False

        # Step 4: Build connection string
        print_step("Building connection string...")
        conn_str = (
            f"DRIVER={DB_CONFIG['driver']};"
            f"SERVER={DB_CONFIG['server']};"
            f"DATABASE={DB_CONFIG['database']};"
            f"UID={DB_CONFIG['username']};"
            f"PWD={DB_CONFIG['password']};"
            f"TrustServerCertificate={DB_CONFIG['trust_server_certificate']};"
            f"Timeout={DB_CONFIG['timeout']}"
        )
        print(f"Connection string: {conn_str}")

        # Step 5: Test connection
        print_step("Attempting to connect to the database...")
        conn = pyodbc.connect(conn_str)
        print("✓ Successfully connected to the database!")

        # Step 6: Test query execution
        print_step("Testing query execution...")
        cursor = conn.cursor()
        
        # Test SQL Server version
        cursor.execute("SELECT @@VERSION")
        version = cursor.fetchone()
        print(f"SQL Server Version: {version[0]}")

        # Test database existence
        print_step("Checking database tables...")
        cursor.execute("""
            SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_TYPE = 'BASE TABLE'
        """)
        tables = cursor.fetchall()
        
        if tables:
            print("Available tables:")
            for table in tables:
                print(f"- {table[0]}")
        else:
            print("No tables found in the database")

        # Step 7: Test specific tables
        print_step("Testing specific tables...")
        required_tables = ['Users', 'Patients', 'Doctors', 'Appointments', 'LabReports']
        for table in required_tables:
            try:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                count = cursor.fetchone()[0]
                print(f"✓ {table}: {count} records found")
            except pyodbc.Error as e:
                print(f"❌ Error accessing {table}: {str(e)}")

        # Step 8: Clean up
        print_step("Cleaning up...")
        cursor.close()
        conn.close()
        print("✓ Connection closed successfully")

        print("\n✅ All tests completed successfully!")
        return True

    except pyodbc.Error as e:
        print(f"\n❌ Database connection error: {str(e)}")
        print("\nTroubleshooting steps:")
        print("1. Check if SQL Server container is running (docker ps)")
        print("2. Verify the connection details:")
        print(f"   - Server: {DB_CONFIG['server']}")
        print(f"   - Database: {DB_CONFIG['database']}")
        print(f"   - Username: {DB_CONFIG['username']}")
        print("3. Ensure the ODBC Driver is installed")
        print("4. Check if the database exists")
        return False
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        print(f"Error type: {type(e).__name__}")
        return False

if __name__ == "__main__":
    print("Starting SQL Server Connection Test...")
    print("=" * 50)
    success = test_connection()
    print("\nTest Result:", "✓ SUCCESS" if success else "❌ FAILED")
    print("=" * 50) 