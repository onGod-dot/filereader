from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import db, Bill, Patient, Doctor
from datetime import datetime
from sqlalchemy import join

billing = Blueprint('billing', __name__)

@billing.route('/billing')
@login_required
def billing_list():
    # Join with Patient and Doctor tables to get names
    bills = db.session.query(
        Bill,
        Patient.name.label('patient_name'),
        Doctor.name.label('doctor_name')
    ).join(
        Patient, Bill.patient_id == Patient.patient_id
    ).join(
        Doctor, Bill.doctor_id == Doctor.doctor_id
    ).all()
    
    return render_template('billing.html', bills=bills)

@billing.route('/billing/add', methods=['GET', 'POST'])
@login_required
def add_bill():
    if request.method == 'POST':
        patient_id = request.form.get('patient_id')
        doctor_id = request.form.get('doctor_id')
        amount = float(request.form.get('amount'))
        bill_date = datetime.strptime(request.form.get('bill_date'), '%Y-%m-%d')
        status = request.form.get('status')

        bill = Bill(
            patient_id=patient_id,
            doctor_id=doctor_id,
            amount=amount,
            bill_date=bill_date,
            status=status
        )

        db.session.add(bill)
        db.session.commit()
        flash('Bill added successfully!', 'success')
        return redirect(url_for('billing.billing_list'))

    patients = Patient.query.all()
    doctors = Doctor.query.all()
    return render_template('add_bill.html', patients=patients, doctors=doctors)

@billing.route('/billing/edit/<int:bill_id>', methods=['GET', 'POST'])
@login_required
def edit_bill(bill_id):
    bill = Bill.query.get_or_404(bill_id)
    
    if request.method == 'POST':
        bill.patient_id = request.form.get('patient_id')
        bill.doctor_id = request.form.get('doctor_id')
        bill.amount = float(request.form.get('amount'))
        bill.bill_date = datetime.strptime(request.form.get('bill_date'), '%Y-%m-%d')
        bill.status = request.form.get('status')

        db.session.commit()
        flash('Bill updated successfully!', 'success')
        return redirect(url_for('billing.billing_list'))

    patients = Patient.query.all()
    doctors = Doctor.query.all()
    return render_template('edit_bill.html', bill=bill, patients=patients, doctors=doctors)

@billing.route('/billing/delete/<int:bill_id>')
@login_required
def delete_bill(bill_id):
    bill = Bill.query.get_or_404(bill_id)
    db.session.delete(bill)
    db.session.commit()
    flash('Bill deleted successfully!', 'success')
    return redirect(url_for('billing.billing_list')) 