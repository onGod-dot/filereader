import pyodbc
from werkzeug.security import generate_password_hash
import re

# Database configuration
DB_CONFIG = {
    'driver': '{ODBC Driver 17 for SQL Server}',
    'server': 'localhost',
    'database': 'master',  # Connect to master first
    'username': 'sa',
    'password': 'YourStrong@Passw0rd',
    'trust_server_certificate': 'yes'
}

def get_db_connection(database='master'):
    conn_str = (
        f"DRIVER={DB_CONFIG['driver']};"
        f"SERVER={DB_CONFIG['server']};"
        f"DATABASE={database};"
        f"UID={DB_CONFIG['username']};"
        f"PWD={DB_CONFIG['password']};"
        f"TrustServerCertificate={DB_CONFIG['trust_server_certificate']}"
    )
    conn = pyodbc.connect(conn_str, autocommit=True)
    return conn

def init_database():
    # First, create the database
    conn = get_db_connection('master')
    cursor = conn.cursor()
    
    try:
        # Check if database exists
        cursor.execute("SELECT name FROM sys.databases WHERE name = N'HealthcareDB'")
        if cursor.fetchone():
            # Drop existing connections
            cursor.execute("ALTER DATABASE HealthcareDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE")
            # Drop database
            cursor.execute("DROP DATABASE HealthcareDB")
        
        # Create new database
        cursor.execute("CREATE DATABASE HealthcareDB")
        print("Database created successfully!")
        
    except Exception as e:
        print(f"Error creating database: {str(e)}")
        return
    finally:
        cursor.close()
        conn.close()
    
    # Now connect to the new database and create schema
    conn = get_db_connection('HealthcareDB')
    cursor = conn.cursor()
    
    try:
        # Read sql.sql
        with open('sql.sql', 'r') as f:
            schema = f.read()
        
        # Split into individual statements and filter out database creation and user creation
        create_statements = []
        insert_statements = []
        other_statements = []
        current_statement = []
        in_create_table = False
        
        for line in schema.split('\n'):
            line = line.strip()
            
            # Skip comments and empty lines
            if not line or line.startswith('--'):
                continue
            
            # Handle CREATE TABLE statements
            if line.upper().startswith('CREATE TABLE'):
                in_create_table = True
                current_statement = [line]
                continue
            
            # If we're in a CREATE TABLE statement
            if in_create_table:
                current_statement.append(line)
                if line.endswith(');'):
                    create_statements.append(' '.join(current_statement))
                    current_statement = []
                    in_create_table = False
                continue
            
            # Handle GO statements
            if line.upper() == 'GO':
                if current_statement:
                    stmt = ' '.join(current_statement)
                    if stmt.upper().startswith('INSERT INTO'):
                        insert_statements.append(stmt)
                    elif any(stmt.upper().startswith(prefix) for prefix in [
                        'CREATE PROCEDURE', 'CREATE FUNCTION', 'CREATE TRIGGER'
                    ]):
                        other_statements.append(stmt)
                    current_statement = []
                continue
            
            # Add line to current statement
            if not in_create_table:
                current_statement.append(line)
        
        # Execute statements in order: CREATE TABLE first, then INSERT INTO, then others
        print("\nCreating tables...")
        for statement in create_statements:
            try:
                cursor.execute(statement)
                print("Table created successfully")
            except Exception as e:
                print(f"Error executing statement: {statement[:100]}...")
                print(f"Error: {str(e)}")
                raise e
        
        print("\nInserting data...")
        for statement in insert_statements:
            try:
                cursor.execute(statement)
                print("Data inserted successfully")
            except Exception as e:
                print(f"Error executing statement: {statement[:100]}...")
                print(f"Error: {str(e)}")
                continue  # Continue with other inserts even if one fails
        
        print("\nCreating procedures, functions, and triggers...")
        for statement in other_statements:
            try:
                cursor.execute(statement)
                print("Object created successfully")
            except Exception as e:
                print(f"Error executing statement: {statement[:100]}...")
                print(f"Error: {str(e)}")
                continue  # Continue with other statements even if one fails
        
        # Create default users with proper password hashes
        print("\nCreating default users...")
        default_password = 'password123'
        password_hash = generate_password_hash(default_password)
        
        # Insert default users
        cursor.execute('''
            INSERT INTO Users (username, password_hash, role) VALUES
            ('admin', ?, 'Admin'),
            ('doctor', ?, 'Doctor'),
            ('receptionist', ?, 'Receptionist'),
            ('nurse', ?, 'Nurse'),
            ('lab_technician', ?, 'Lab Technician')
        ''', (password_hash, password_hash, password_hash, password_hash, password_hash))
        
        print("\nSchema initialized successfully!")
        print("\nDefault login credentials:")
        print("Username: admin")
        print("Password: password123")
        
    except Exception as e:
        print(f"Error initializing schema: {str(e)}")
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    init_database() 