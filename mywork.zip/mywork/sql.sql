-- Create the Healthcare Database
CREATE DATABASE HealthcareDB;
GO
USE HealthcareDB;
GO

-- Patients Table
CREATE TABLE Patients (
    patient_id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    dob DATE NOT NULL,
    gender VARCHAR(10) NOT NULL CHECK (gender IN ('Male', 'Female', 'Other')),
    contact VARCHAR(15) UNIQUE NOT NULL,
    address TEXT NOT NULL
);
GO

-- Doctors Table
CREATE TABLE Doctors (
    doctor_id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    contact VARCHAR(15) UNIQUE NOT NULL
);
GO

-- Appointments Table
CREATE TABLE Appointments (
    appointment_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    date_time DATETIME NOT NULL,
    status VARCHAR(20) DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'Completed', 'Cancelled')),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id) ON DELETE CASCADE
);
GO

-- Prescriptions Table
CREATE TABLE Prescriptions (
    prescription_id INT IDENTITY(1,1) PRIMARY KEY,
    appointment_id INT,
    patient_id INT,
    doctor_id INT,
    medicine TEXT NOT NULL,
    dosage TEXT NOT NULL,
    instructions TEXT NOT NULL,
    FOREIGN KEY (appointment_id) REFERENCES Appointments(appointment_id) ON DELETE CASCADE,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id) ON DELETE NO ACTION,
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id) ON DELETE NO ACTION
);
GO

-- Users Table (For Authentication & Role Management)
CREATE TABLE Users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('Admin', 'Doctor', 'Receptionist', 'Patient', 'Nurse', 'Lab Technician'))
);
GO

-- Insert Patients 
INSERT INTO Patients (name, dob, gender, contact, address) VALUES
('Kwame Owusu', '1988-03-20', 'Male', '0244123456', 'Accra Newtown'),
('Ama Serwaa', '1992-07-12', 'Female', '0505678901', 'Kumasi Bantama'),
('Yaw Mensah', '1975-11-05', 'Male', '0209876543', 'Takoradi Beach Road'),
('Akosua Boateng', '2001-01-28', 'Female', '0551234567', 'Cape Coast Castle View'),
('Kofi Asante', '1963-09-18', 'Male', '0267890123', 'Tamale Market Square');

-- Insert Doctors 
INSERT INTO Doctors (name, specialization, contact) VALUES
('Dr. Esi Mensah', 'General Medicine', '0278901234'),
('Dr. Kwame Nkrumah', 'Pediatrics', '0543210987'),
('Dr. Afua Koomson', 'Obstetrics/Gynecology', '0281234567'),
('Dr. Osei Tutu', 'Surgery', '0567890123');

-- Insert Appointments
INSERT INTO Appointments (patient_id, doctor_id, date_time) VALUES
(1, 1, '2025-03-15 09:00:00'),
(2, 2, '2025-03-16 11:30:00'),
(3, 3, '2025-03-17 13:00:00'),
(4, 4, '2025-03-18 15:45:00'),
(5, 1, '2025-03-19 10:15:00');

-- Insert Prescriptions
INSERT INTO Prescriptions (appointment_id, patient_id, doctor_id, medicine, dosage, instructions) VALUES
(1, 1, 1, 'Amoxicillin', '500mg', 'Take three times daily'),
(2, 2, 2, 'Vitamin C', '1000mg', 'Take once daily in the morning'),
(3, 3, 3, 'Iron Supplement', '25mg', 'Take once daily with food'),
(4, 4, 4, 'Pain Reliever', '200mg', 'Take as needed for pain'),
(5, 5, 1, 'Multivitamin', '1 tablet', 'Take once daily');

-- Insert Users with Ghanaian-related usernames
INSERT INTO Users (username, password_hash, role) VALUES
('admin_gh', 'hashed_password_1', 'Admin'),
('dr_esi', 'hashed_password_2', 'Doctor'),
('reception_ama', 'hashed_password_3', 'Receptionist'),
('patient_kwame', 'hashed_password_4', 'Patient'),
('dr_kwame', 'hashed_password_5', 'Doctor');

-- Create Users for SQL Server Authentication (Change passwords accordingly)
CREATE LOGIN admin_user WITH PASSWORD = 'hashed_password_1';
CREATE LOGIN doctor_user WITH PASSWORD = 'hashed_password_2';
CREATE LOGIN receptionist_user WITH PASSWORD = 'hashed_password_3';
CREATE LOGIN patient_user WITH PASSWORD = 'hashed_password_4';
GO

-- Create Database Users
CREATE USER admin_user FOR LOGIN admin_user;
CREATE USER doctor_user FOR LOGIN doctor_user;
CREATE USER receptionist_user FOR LOGIN receptionist_user;
CREATE USER patient_user FOR LOGIN patient_user;
GO

-- Grant Permissions
GRANT ALL PRIVILEGES ON DATABASE::HealthcareDB TO admin_user;

GRANT SELECT, INSERT, UPDATE ON Patients TO doctor_user;
GRANT SELECT, INSERT, UPDATE ON Prescriptions TO doctor_user;

GRANT SELECT, INSERT, UPDATE ON Appointments TO receptionist_user;

GRANT SELECT ON Patients TO patient_user;
GRANT SELECT ON Appointments TO patient_user;

-- Revoke 
REVOKE INSERT ON Patients FROM patient_user;
GO
-- Stored Procedure to Register a Patient
CREATE PROCEDURE RegisterPatient
    @p_name VARCHAR(100),
    @p_dob DATE,
    @p_gender VARCHAR(10),
    @p_contact VARCHAR(15),
    @p_address TEXT
AS
BEGIN
    INSERT INTO Patients (name, dob, gender, contact, address)
    VALUES (@p_name, @p_dob, @p_gender, @p_contact, @p_address);
END;
GO

-- Execute Stored Procedure
EXEC RegisterPatient 'Michael Quasie', '1992-08-30', 'Male', '1231231234', 'Kumasi';
GO

-- Creating a Audit Log Table
CREATE TABLE Patient_Audit_Log (
    log_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT,
    change_type VARCHAR(50),
    change_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id) ON DELETE CASCADE
);
GO

-- Creating a Trigger to Log Patient Updates
CREATE TRIGGER LogPatientUpdate
ON Patients
AFTER UPDATE
AS
BEGIN
    INSERT INTO Patient_Audit_Log (patient_id, change_type)
    SELECT patient_id, 'Updated Record' FROM inserted;
END;
GO


--creating function
CREATE FUNCTION GetDoctorAppointments(@d_id INT) RETURNS INT
AS
BEGIN
    DECLARE @total INT;
    SELECT @total = COUNT(*) FROM Appointments WHERE doctor_id = @d_id;
    RETURN @total;
END;
GO

-- Test Function
SELECT dbo.GetDoctorAppointments(1);
GO

--If else statement 

CREATE PROCEDURE BookAppointment
    @patient_id INT,
    @doctor_id INT,
    @date_time DATETIME
AS
BEGIN
    -- Check if the doctor has an existing appointment at the same time
    IF EXISTS (
        SELECT 1 FROM Appointments 
        WHERE doctor_id = @doctor_id 
        AND date_time = @date_time
    )
    BEGIN
        PRINT 'Error: The doctor is not available at this time. Choose another slot.';
        RETURN;
    END

 -- Insert the appointment if the doctor is available
    INSERT INTO Appointments (patient_id, doctor_id, date_time)
    VALUES (@patient_id, @doctor_id, @date_time);

    PRINT 'Appointment booked successfully!';
END;
GO

EXEC BookAppointment @patient_id = 1, @doctor_id = 2, @date_time = '2025-03-20 10:00:00';

--trying to book when a doctor is busy
EXEC BookAppointment @patient_id = 3, @doctor_id = 2, @date_time = '2025-03-16 11:30:00';

--backing up the database to my hard disk
BACKUP DATABASE HealthcareDB  
TO DISK = '/var/opt/mssql/backups/HealthcareDB_Backup.bak'  
WITH FORMAT,  
MEDIANAME = 'SQLServerBackups',  
NAME = 'Full Backup of HealthcareDB';
GO


-- Restore the Full Backup 
RESTORE DATABASE HealthcareDB  
FROM DISK = '/var/opt/mssql/backups/HealthcareDB_Backup.bak'  
WITH NORECOVERY,  
MOVE 'HealthcareDB' TO '/var/opt/mssql/data/HealthcareDB.mdf',  
MOVE 'HealthcareDB_log' TO '/var/opt/mssql/data/HealthcareDB_log.ldf';
GO
SELECT * FROM Patients;

-- Billing Table
CREATE TABLE Billing (
    bill_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT,
    appointment_id INT,
    amount DECIMAL(10,2) NOT NULL,
    bill_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Pending' CHECK (status IN ('Pending', 'Paid', 'Cancelled')),
    payment_method VARCHAR(50),
    payment_date DATETIME,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id) ON DELETE NO ACTION,
    FOREIGN KEY (appointment_id) REFERENCES Appointments(appointment_id) ON DELETE NO ACTION
);
GO

-- Lab Reports Table
CREATE TABLE LabReports (
    report_id INT IDENTITY(1,1) PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    test_name VARCHAR(100) NOT NULL,
    test_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    results TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'Pending' CHECK (status IN ('Pending', 'Completed', 'Cancelled')),
    file_path VARCHAR(255),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id) ON DELETE CASCADE
);
GO

-- Insert sample billing records
INSERT INTO Billing (patient_id, appointment_id, amount, status, payment_method, payment_date) VALUES
(1, 1, 50.00, 'Paid', 'Cash', '2024-03-15 09:30:00'),
(2, 2, 75.00, 'Pending', NULL, NULL),
(3, 3, 100.00, 'Paid', 'Credit Card', '2024-03-17 13:30:00'),
(4, 4, 150.00, 'Pending', NULL, NULL),
(5, 5, 80.00, 'Paid', 'Mobile Money', '2024-03-19 10:30:00');
GO

-- Insert sample lab reports
INSERT INTO LabReports (patient_id, doctor_id, test_name, results, status) VALUES
(1, 1, 'Blood Test', 'Normal blood count and hemoglobin levels', 'Completed'),
(2, 2, 'Urine Analysis', 'No abnormalities detected', 'Completed'),
(3, 3, 'X-Ray', 'Clear chest X-ray', 'Completed'),
(4, 4, 'MRI Scan', 'Pending analysis', 'Pending'),
(5, 1, 'Blood Sugar Test', 'Normal glucose levels', 'Completed');
GO