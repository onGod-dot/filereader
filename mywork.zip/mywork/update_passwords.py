import pyodbc
from werkzeug.security import generate_password_hash

# Database configuration
DB_CONFIG = {
    'driver': '{ODBC Driver 17 for SQL Server}',
    'server': 'localhost',
    'database': 'HealthcareDB',
    'username': 'sa',
    'password': 'YourStrong@Passw0rd',
    'trust_server_certificate': 'yes'
}

def update_passwords():
    # Define users and their passwords
    users = [
        {'username': 'admin_gh', 'password': 'admin123', 'role': 'Admin'},
        {'username': 'dr_esi', 'password': 'doctor123', 'role': 'Doctor'},
        {'username': 'reception_ama', 'password': 'reception123', 'role': 'Receptionist'},
        {'username': 'patient_kwame', 'password': 'patient123', 'role': 'Patient'},
        {'username': 'dr_kwame', 'password': 'doctor123', 'role': 'Doctor'}
    ]
    
    try:
        # Create connection string
        conn_str = (
            f"DRIVER={DB_CONFIG['driver']};"
            f"SERVER={DB_CONFIG['server']};"
            f"DATABASE={DB_CONFIG['database']};"
            f"UID={DB_CONFIG['username']};"
            f"PWD={DB_CONFIG['password']};"
            f"TrustServerCertificate={DB_CONFIG['trust_server_certificate']}"
        )
        
        # Connect to database
        print("Connecting to database...")
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()
        
        # Update passwords for each user
        for user in users:
            password_hash = generate_password_hash(user['password'])
            cursor.execute('''
                UPDATE Users 
                SET password_hash = ?
                WHERE username = ?
            ''', (password_hash, user['username']))
            print(f"Updated password for user: {user['username']}")
        
        # Commit changes
        conn.commit()
        print("\nAll passwords updated successfully!")
        
        # Close connection
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"Error updating passwords: {str(e)}")

if __name__ == "__main__":
    print("Starting password update...")
    update_passwords() 