from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
import pyodbc
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

# Database configuration
DB_CONFIG = {
    'driver': '{ODBC Driver 17 for SQL Server}',
    'server': 'localhost,1433',  # Added port number
    'database': 'HealthcareDB',
    'username': 'sa',
    'password': 'YourStrong@Passw0rd',
    'trust_server_certificate': 'yes',
    'timeout': 30  # Added timeout
}

def get_db_connection():
    try:
        conn_str = (
            f"DRIVER={DB_CONFIG['driver']};"
            f"SERVER={DB_CONFIG['server']};"
            f"DATABASE={DB_CONFIG['database']};"
            f"UID={DB_CONFIG['username']};"
            f"PWD={DB_CONFIG['password']};"
            f"TrustServerCertificate={DB_CONFIG['trust_server_certificate']};"
            f"Timeout={DB_CONFIG['timeout']}"
        )
        return pyodbc.connect(conn_str)
    except pyodbc.Error as e:
        print(f"Database connection error: {str(e)}")
        print("Please check if:")
        print("1. SQL Server is running")
        print("2. The connection details are correct")
        print("3. The ODBC Driver is installed")
        raise

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, user_data):
        self.user_id = user_data.user_id
        self.username = user_data.username
        self.role = user_data.role

    def get_id(self):
        return str(self.user_id)

    @staticmethod
    def get(user_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Users WHERE user_id = ?', (user_id,))
        user_data = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if user_data:
            return User(user_data)
        return None

    def is_admin(self):
        return self.role == 'Admin'

    def is_doctor(self):
        return self.role == 'Doctor'

    def is_receptionist(self):
        return self.role == 'Receptionist'

    def is_nurse(self):
        return self.role == 'Nurse'

    def is_lab_technician(self):
        return self.role == 'Lab Technician'

    def is_patient(self):
        return self.role == 'Patient'

# Login manager configuration
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Users WHERE username = ?', (username,))
        user_data = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if user_data and check_password_hash(user_data.password_hash, password):
            user = User(user_data)
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        
        flash('Invalid username or password.', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get counts
        cursor.execute('SELECT COUNT(*) FROM Patients')
        patient_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM Doctors')
        doctor_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM Appointments')
        appointment_count = cursor.fetchone()[0]
        
        # Get recent appointments
        if current_user.role == 'Doctor':
            cursor.execute('''
                SELECT TOP 5 a.*, p.name as patient_name
                FROM Appointments a
                JOIN Patients p ON a.patient_id = p.patient_id
                WHERE a.doctor_id = ?
                ORDER BY a.date_time DESC
            ''', (current_user.user_id,))
        else:
            cursor.execute('''
                SELECT TOP 5 a.*, p.name as patient_name
                FROM Appointments a
                JOIN Patients p ON a.patient_id = p.patient_id
                ORDER BY a.date_time DESC
            ''')
        recent_appointments = cursor.fetchall()
        
        # Get recent patients
        cursor.execute('''
            SELECT TOP 5 p.*
            FROM Patients p
            ORDER BY p.patient_id DESC
        ''')
        recent_patients = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return render_template('dashboard.html',
                             patient_count=patient_count,
                             doctor_count=doctor_count,
                             appointment_count=appointment_count,
                             recent_appointments=recent_appointments,
                             recent_patients=recent_patients)
    except Exception as e:
        print(f"Error in dashboard: {str(e)}")
        return render_template('dashboard.html',
                             patient_count=0,
                             doctor_count=0,
                             appointment_count=0,
                             recent_appointments=[],
                             recent_patients=[])

# Patient Management Routes
@app.route('/patients')
@login_required
def manage_patients():
    if current_user.role not in ['Admin', 'Doctor', 'Receptionist']:
        flash('Access denied. Insufficient permissions.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT p.*, 
               (SELECT COUNT(*) FROM Appointments WHERE patient_id = p.patient_id) as appointment_count
        FROM Patients p
        ORDER BY p.name
    ''')
    patients = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('patients.html', patients=patients)

@app.route('/add_patient', methods=['GET', 'POST'])
@login_required
def add_patient():
    if current_user.role not in ['Admin', 'Receptionist']:
        flash('Access denied. Insufficient permissions.', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        name = request.form['name']
        dob = request.form['dob']
        gender = request.form['gender']
        contact = request.form['contact']
        address = request.form['address']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO Patients (name, dob, gender, contact, address)
                VALUES (?, ?, ?, ?, ?)
            ''', (name, dob, gender, contact, address))
            conn.commit()
            flash('Patient added successfully!', 'success')
            return redirect(url_for('manage_patients'))
        except Exception as e:
            print(f"Error adding patient: {str(e)}")
            flash('Error adding patient.', 'error')
        finally:
            cursor.close()
            conn.close()
    
    return render_template('add_patient.html')

@app.route('/edit_patient/<int:patient_id>', methods=['GET', 'POST'])
@login_required
def edit_patient(patient_id):
    if current_user.role not in ['Admin', 'Doctor', 'Receptionist']:
        flash('Access denied. Insufficient permissions.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        gender = request.form['gender']
        contact = request.form['contact']
        address = request.form['address']
        
        try:
            cursor.execute('''
                UPDATE Patients 
                SET name = ?, age = ?, gender = ?, contact = ?, address = ?
                WHERE patient_id = ?
            ''', (name, age, gender, contact, address, patient_id))
            conn.commit()
            flash('Patient updated successfully!', 'success')
            return redirect(url_for('manage_patients'))
        except Exception as e:
            print(f"Error updating patient: {str(e)}")
            flash('Error updating patient.', 'error')
        finally:
            cursor.close()
            conn.close()
    
    cursor.execute('SELECT * FROM Patients WHERE patient_id = ?', (patient_id,))
    patient = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if not patient:
        flash('Patient not found.', 'error')
        return redirect(url_for('manage_patients'))
    
    return render_template('edit_patient.html', patient=patient)

@app.route('/delete_patient/<int:patient_id>')
@login_required
def delete_patient(patient_id):
    if current_user.role not in ['Admin']:
        flash('Access denied. Insufficient permissions.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('DELETE FROM Patients WHERE patient_id = ?', (patient_id,))
        conn.commit()
        flash('Patient deleted successfully!', 'success')
    except Exception as e:
        print(f"Error deleting patient: {str(e)}")
        flash('Error deleting patient.', 'error')
    finally:
        cursor.close()
        conn.close()
    
    return redirect(url_for('manage_patients'))

# Doctor Management Routes
@app.route('/doctors')
@login_required
def manage_doctors():
    if current_user.role != 'Admin':
        flash('Access denied. Only administrators can manage doctors.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT d.*, 
               (SELECT COUNT(*) FROM Appointments WHERE doctor_id = d.doctor_id) as appointment_count
        FROM Doctors d
        ORDER BY d.name
    ''')
    doctors = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('doctors.html', doctors=doctors)

@app.route('/add_doctor', methods=['GET', 'POST'])
@login_required
def add_doctor():
    if current_user.role != 'Admin':
        flash('Access denied. Only administrators can add doctors.', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        name = request.form['name']
        specialization = request.form['specialization']
        contact = request.form['contact']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO Doctors (name, specialization, contact)
                VALUES (?, ?, ?)
            ''', (name, specialization, contact))
            conn.commit()
            flash('Doctor added successfully!', 'success')
            return redirect(url_for('manage_doctors'))
        except Exception as e:
            print(f"Error adding doctor: {str(e)}")
            flash('Error adding doctor.', 'error')
        finally:
            cursor.close()
            conn.close()
    
    return render_template('add_doctor.html')

@app.route('/edit_doctor/<int:doctor_id>', methods=['GET', 'POST'])
@login_required
def edit_doctor(doctor_id):
    if current_user.role != 'Admin':
        flash('Access denied. Only administrators can edit doctors.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        name = request.form['name']
        specialization = request.form['specialization']
        contact = request.form['contact']
        
        try:
            cursor.execute('''
                UPDATE Doctors 
                SET name = ?, specialization = ?, contact = ?
                WHERE doctor_id = ?
            ''', (name, specialization, contact, doctor_id))
            conn.commit()
            flash('Doctor updated successfully!', 'success')
            return redirect(url_for('manage_doctors'))
        except Exception as e:
            print(f"Error updating doctor: {str(e)}")
            flash('Error updating doctor.', 'error')
        finally:
            cursor.close()
            conn.close()
    
    cursor.execute('SELECT * FROM Doctors WHERE doctor_id = ?', (doctor_id,))
    doctor = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if not doctor:
        flash('Doctor not found.', 'error')
        return redirect(url_for('manage_doctors'))
    
    return render_template('edit_doctor.html', doctor=doctor)

@app.route('/delete_doctor/<int:doctor_id>')
@login_required
def delete_doctor(doctor_id):
    if current_user.role != 'Admin':
        flash('Access denied. Only administrators can delete doctors.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # First delete related records
        cursor.execute('DELETE FROM Appointments WHERE doctor_id = ?', (doctor_id,))
        cursor.execute('DELETE FROM Prescriptions WHERE doctor_id = ?', (doctor_id,))
        cursor.execute('DELETE FROM LabReports WHERE doctor_id = ?', (doctor_id,))
        
        # Finally delete the doctor
        cursor.execute('DELETE FROM Doctors WHERE doctor_id = ?', (doctor_id,))
        conn.commit()
        flash('Doctor deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting doctor: {str(e)}', 'error')
    finally:
        cursor.close()
        conn.close()
    
    return redirect(url_for('manage_doctors'))

# Appointment Management Routes
@app.route('/appointments')
@login_required
def manage_appointments():
    if not (current_user.is_admin() or current_user.is_doctor() or current_user.is_receptionist()):
        flash('Access denied. Insufficient permissions.', 'danger')
        return redirect(url_for('dashboard'))
    
    cursor = get_db_connection().cursor()
    
    # Get appointments with patient and doctor names
    cursor.execute('''
        SELECT a.appointment_id, a.date_time, a.status,
               p.name as patient_name,
               d.name as doctor_name
        FROM Appointments a
        JOIN Patients p ON a.patient_id = p.patient_id
        JOIN Doctors d ON a.doctor_id = d.doctor_id
        ORDER BY a.date_time DESC
    ''')
    appointments = cursor.fetchall()
    
    # Get patients for dropdown
    cursor.execute('SELECT patient_id, name FROM Patients ORDER BY name')
    patients = cursor.fetchall()
    
    # Get doctors for dropdown
    cursor.execute('SELECT doctor_id, name FROM Doctors ORDER BY name')
    doctors = cursor.fetchall()
    
    return render_template('manage_appointments.html', 
                         appointments=appointments,
                         patients=patients,
                         doctors=doctors)

@app.route('/appointments/add', methods=['GET', 'POST'])
@login_required
def add_appointment():
    if not (current_user.is_admin() or current_user.is_doctor() or current_user.is_receptionist()):
        flash('Access denied. Insufficient permissions.', 'danger')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        try:
            patient_id = request.form['patient_id']
            doctor_id = request.form['doctor_id']
            appointment_date = datetime.strptime(request.form['appointment_date'], '%Y-%m-%d')
            appointment_time = request.form['appointment_time']
            status = request.form['status']

            # Combine date and time
            appointment_datetime = datetime.combine(appointment_date, datetime.strptime(appointment_time, '%H:%M').time())

            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO Appointments (patient_id, doctor_id, date_time, status)
                VALUES (?, ?, ?, ?)
            ''', (patient_id, doctor_id, appointment_datetime, status))
            conn.commit()
            flash('Appointment added successfully!', 'success')
            return redirect(url_for('manage_appointments'))
        except Exception as e:
            print(f"Error adding appointment: {str(e)}")
            flash(f'Error adding appointment: {str(e)}', 'error')
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()
    
    # Get patients and doctors for the form
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT patient_id, name FROM Patients ORDER BY name')
    patients = cursor.fetchall()
    
    cursor.execute('SELECT doctor_id, name FROM Doctors ORDER BY name')
    doctors = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('add_appointment.html', patients=patients, doctors=doctors)

@app.route('/appointments/edit/<int:appointment_id>', methods=['GET', 'POST'])
@login_required
def edit_appointment(appointment_id):
    if not (current_user.is_admin() or current_user.is_doctor() or current_user.is_receptionist()):
        flash('Access denied. Insufficient permissions.', 'danger')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        try:
            patient_id = request.form['patient_id']
            doctor_id = request.form['doctor_id']
            appointment_date = datetime.strptime(request.form['appointment_date'], '%Y-%m-%d')
            appointment_time = request.form['appointment_time']
            status = request.form['status']

            # Combine date and time
            appointment_datetime = datetime.combine(appointment_date, datetime.strptime(appointment_time, '%H:%M').time())
            
            cursor.execute('''
                UPDATE Appointments 
                SET patient_id = ?, doctor_id = ?, date_time = ?, status = ?
                WHERE appointment_id = ?
            ''', (patient_id, doctor_id, appointment_datetime, status, appointment_id))
            conn.commit()
            
            flash('Appointment updated successfully!', 'success')
            return redirect(url_for('manage_appointments'))
        except Exception as e:
            print(f"Error updating appointment: {str(e)}")
            flash(f'Error updating appointment: {str(e)}', 'error')
        finally:
            cursor.close()
            conn.close()
    
    # Get appointment details
    cursor.execute('''
        SELECT a.*, p.name as patient_name,
               d.name as doctor_name
        FROM Appointments a
        JOIN Patients p ON a.patient_id = p.patient_id
        JOIN Doctors d ON a.doctor_id = d.doctor_id
        WHERE a.appointment_id = ?
    ''', (appointment_id,))
    appointment = cursor.fetchone()
    
    if not appointment:
        flash('Appointment not found.', 'error')
        return redirect(url_for('manage_appointments'))
    
    # Get patients and doctors for dropdowns
    cursor.execute('SELECT patient_id, name FROM Patients ORDER BY name')
    patients = cursor.fetchall()
    
    cursor.execute('SELECT doctor_id, name FROM Doctors ORDER BY name')
    doctors = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('edit_appointment.html', 
                         appointment=appointment,
                         patients=patients,
                         doctors=doctors)

@app.route('/appointments/delete/<int:appointment_id>')
@login_required
def delete_appointment(appointment_id):
    if not (current_user.is_admin() or current_user.is_doctor() or current_user.is_receptionist()):
        flash('Access denied. Insufficient permissions.', 'danger')
        return redirect(url_for('dashboard'))
    
    try:
        cursor = get_db_connection().cursor()
        cursor.execute('DELETE FROM Appointments WHERE appointment_id = ?', (appointment_id,))
        get_db_connection().commit()
        flash('Appointment deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting appointment: {str(e)}', 'danger')
    
    return redirect(url_for('manage_appointments'))

# Prescription Management Routes
@app.route('/prescriptions')
@login_required
def manage_prescriptions():
    if not (current_user.is_admin() or current_user.is_doctor()):
        flash('Access denied. Insufficient permissions.', 'danger')
        return redirect(url_for('dashboard'))
    
    cursor = get_db_connection().cursor()
    
    if current_user.is_doctor():
        cursor.execute('''
            SELECT pr.*, p.name as patient_name,
                   d.name as doctor_name,
                   a.date_time
            FROM Prescriptions pr
            JOIN Patients p ON pr.patient_id = p.patient_id
            JOIN Appointments a ON pr.appointment_id = a.appointment_id
            JOIN Doctors d ON a.doctor_id = d.doctor_id
            WHERE a.doctor_id = ?
            ORDER BY a.date_time DESC
        ''', (current_user.user_id,))
    else:
        cursor.execute('''
            SELECT pr.*, p.name as patient_name,
                   d.name as doctor_name,
                   a.date_time
            FROM Prescriptions pr
            JOIN Patients p ON pr.patient_id = p.patient_id
            JOIN Appointments a ON pr.appointment_id = a.appointment_id
            JOIN Doctors d ON a.doctor_id = d.doctor_id
            ORDER BY a.date_time DESC
        ''')
    
    prescriptions = cursor.fetchall()
    return render_template('prescriptions.html', prescriptions=prescriptions)

@app.route('/prescriptions/add', methods=['GET', 'POST'])
@login_required
def add_prescription():
    if not (current_user.is_admin() or current_user.is_doctor()):
        flash('Access denied. Insufficient permissions.', 'danger')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        try:
            patient_id = request.form['patient_id']
            appointment_id = request.form['appointment_id']
            medication = request.form['medication']
            dosage = request.form['dosage']
            instructions = request.form['instructions']
            
            cursor = get_db_connection().cursor()
            cursor.execute('''
                INSERT INTO Prescriptions (patient_id, appointment_id, medication, dosage, instructions)
                VALUES (?, ?, ?, ?, ?)
            ''', (patient_id, appointment_id, medication, dosage, instructions))
            get_db_connection().commit()
            
            flash('Prescription added successfully!', 'success')
            return redirect(url_for('manage_prescriptions'))
        except Exception as e:
            flash(f'Error adding prescription: {str(e)}', 'danger')
            return redirect(url_for('add_prescription'))
    
    cursor = get_db_connection().cursor()
    cursor.execute('SELECT patient_id, name FROM Patients ORDER BY name')
    patients = cursor.fetchall()
    
    cursor.execute('''
        SELECT a.*, p.name as patient_name,
               d.name as doctor_name
        FROM Appointments a
        JOIN Patients p ON a.patient_id = p.patient_id
        JOIN Doctors d ON a.doctor_id = d.doctor_id
        ORDER BY a.date_time DESC
    ''')
    appointments = cursor.fetchall()
    
    return render_template('add_prescription.html', patients=patients, appointments=appointments)

@app.route('/prescriptions/edit/<int:prescription_id>', methods=['GET', 'POST'])
@login_required
def edit_prescription(prescription_id):
    if not (current_user.is_admin() or current_user.is_doctor()):
        flash('Access denied. Insufficient permissions.', 'danger')
        return redirect(url_for('dashboard'))
    
    cursor = get_db_connection().cursor()
    
    if request.method == 'POST':
        try:
            patient_id = request.form['patient_id']
            appointment_id = request.form['appointment_id']
            medication = request.form['medication']
            dosage = request.form['dosage']
            instructions = request.form['instructions']
            
            cursor.execute('''
                UPDATE Prescriptions 
                SET patient_id = ?, appointment_id = ?, medication = ?, dosage = ?, instructions = ?
                WHERE prescription_id = ?
            ''', (patient_id, appointment_id, medication, dosage, instructions, prescription_id))
            get_db_connection().commit()
            
            flash('Prescription updated successfully!', 'success')
            return redirect(url_for('manage_prescriptions'))
        except Exception as e:
            flash(f'Error updating prescription: {str(e)}', 'danger')
            return redirect(url_for('edit_prescription', prescription_id=prescription_id))
    
    cursor.execute('''
        SELECT pr.*, p.name as patient_name,
               d.name as doctor_name
        FROM Prescriptions pr
        JOIN Patients p ON pr.patient_id = p.patient_id
        JOIN Appointments a ON pr.appointment_id = a.appointment_id
        JOIN Doctors d ON a.doctor_id = d.doctor_id
        WHERE pr.prescription_id = ?
    ''', (prescription_id,))
    prescription = cursor.fetchone()
    
    if not prescription:
        flash('Prescription not found.', 'danger')
        return redirect(url_for('manage_prescriptions'))
    
    cursor.execute('SELECT patient_id, name FROM Patients ORDER BY name')
    patients = cursor.fetchall()
    
    cursor.execute('''
        SELECT a.*, p.name as patient_name,
               d.name as doctor_name
        FROM Appointments a
        JOIN Patients p ON a.patient_id = p.patient_id
        JOIN Doctors d ON a.doctor_id = d.doctor_id
        ORDER BY a.date_time DESC
    ''')
    appointments = cursor.fetchall()
    
    return render_template('edit_prescription.html', 
                         prescription=prescription,
                         patients=patients,
                         appointments=appointments)

@app.route('/prescriptions/delete/<int:prescription_id>')
@login_required
def delete_prescription(prescription_id):
    if not current_user.is_admin():
        flash('Access denied. Only administrators can delete prescriptions.', 'danger')
        return redirect(url_for('dashboard'))
    
    try:
        cursor = get_db_connection().cursor()
        cursor.execute('DELETE FROM Prescriptions WHERE prescription_id = ?', (prescription_id,))
        get_db_connection().commit()
        flash('Prescription deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting prescription: {str(e)}', 'danger')
    
    return redirect(url_for('manage_prescriptions'))

@app.route('/prescriptions/view/<int:prescription_id>')
@login_required
def view_prescription(prescription_id):
    if not (current_user.is_admin() or current_user.is_doctor() or current_user.is_receptionist()):
        flash('Access denied. Insufficient permissions.', 'danger')
        return redirect(url_for('dashboard'))
    
    cursor = get_db_connection().cursor()
    
    cursor.execute('''
        SELECT pr.*, p.name as patient_name,
               d.name as doctor_name,
               p.contact as patient_contact, d.contact as doctor_contact,
               d.specialization as doctor_specialization, a.date_time
        FROM Prescriptions pr
        JOIN Patients p ON pr.patient_id = p.patient_id
        JOIN Appointments a ON pr.appointment_id = a.appointment_id
        JOIN Doctors d ON a.doctor_id = d.doctor_id
        WHERE pr.prescription_id = ?
    ''', (prescription_id,))
    
    prescription = cursor.fetchone()
    
    if not prescription:
        flash('Prescription not found.', 'danger')
        return redirect(url_for('manage_prescriptions'))
    
    return render_template('view_prescription.html', prescription=prescription)

# Lab Reports Management Routes
@app.route('/lab_reports')
@login_required
def manage_lab_reports():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT lr.*, p.name as patient_name,
                   d.name as doctor_name
            FROM LabReports lr
            JOIN Patients p ON lr.patient_id = p.patient_id
            JOIN Doctors d ON lr.doctor_id = d.doctor_id
            ORDER BY lr.date DESC
        ''')
        reports = cursor.fetchall()
        return render_template('lab_reports.html', reports=reports)
    except Exception as e:
        flash(f'Error fetching lab reports: {str(e)}', 'danger')
        return render_template('lab_reports.html', reports=[])
    finally:
        cursor.close()
        conn.close()

@app.route('/lab_reports/add', methods=['GET', 'POST'])
@login_required
def add_lab_report():
    if current_user.role not in ['Admin', 'Doctor', 'Lab Technician']:
        flash('You do not have permission to add lab reports.', 'danger')
        return redirect(url_for('manage_lab_reports'))
    
    if request.method == 'POST':
        patient_id = request.form.get('patient_id')
        doctor_id = request.form.get('doctor_id')
        test_name = request.form.get('test_name')
        results = request.form.get('results')
        status = request.form.get('status')
        date = request.form.get('report_date')  # Keep the form field name as report_date
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO LabReports (patient_id, doctor_id, test_name, results, status, date)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (patient_id, doctor_id, test_name, results, status, date))
            conn.commit()
            flash('Lab report added successfully!', 'success')
            return redirect(url_for('manage_lab_reports'))
        except Exception as e:
            flash(f'Error adding lab report: {str(e)}', 'danger')
        finally:
            cursor.close()
            conn.close()
    
    # Get lists of patients and doctors for the form
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT patient_id, name FROM Patients ORDER BY name')
        patients = cursor.fetchall()
        
        cursor.execute('SELECT doctor_id, name FROM Doctors ORDER BY name')
        doctors = cursor.fetchall()
        
        return render_template('add_lab_report.html', patients=patients, doctors=doctors)
    except Exception as e:
        flash(f'Error loading form data: {str(e)}', 'danger')
        return redirect(url_for('manage_lab_reports'))
    finally:
        cursor.close()
        conn.close()

@app.route('/lab_reports/<int:report_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_lab_report(report_id):
    if current_user.role not in ['Admin', 'Doctor', 'Lab Technician']:
        flash('You do not have permission to edit lab reports.', 'danger')
        return redirect(url_for('manage_lab_reports'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        if request.method == 'POST':
            patient_id = request.form.get('patient_id')
            doctor_id = request.form.get('doctor_id')
            test_name = request.form.get('test_name')
            results = request.form.get('results')
            status = request.form.get('status')
            date = request.form.get('report_date')  # Keep the form field name as report_date
            
            cursor.execute('''
                UPDATE LabReports
                SET patient_id = ?, doctor_id = ?, test_name = ?, results = ?, status = ?, date = ?
                WHERE report_id = ?
            ''', (patient_id, doctor_id, test_name, results, status, date, report_id))
            conn.commit()
            flash('Lab report updated successfully!', 'success')
            return redirect(url_for('manage_lab_reports'))
        
        # Get the lab report data
        cursor.execute('''
            SELECT * FROM LabReports WHERE report_id = ?
        ''', (report_id,))
        report = cursor.fetchone()
        
        if not report:
            flash('Lab report not found.', 'danger')
            return redirect(url_for('manage_lab_reports'))
        
        # Get lists of patients and doctors for the form
        cursor.execute('SELECT patient_id, name FROM Patients ORDER BY name')
        patients = cursor.fetchall()
        
        cursor.execute('SELECT doctor_id, name FROM Doctors ORDER BY name')
        doctors = cursor.fetchall()
        
        return render_template('edit_lab_report.html', report=report, patients=patients, doctors=doctors)
    except Exception as e:
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('manage_lab_reports'))
    finally:
        cursor.close()
        conn.close()

@app.route('/lab_reports/<int:report_id>/delete', methods=['POST'])
@login_required
def delete_lab_report(report_id):
    if current_user.role not in ['Admin', 'Doctor', 'Lab Technician']:
        flash('You do not have permission to delete lab reports.', 'danger')
        return redirect(url_for('manage_lab_reports'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('DELETE FROM LabReports WHERE report_id = ?', (report_id,))
        conn.commit()
        flash('Lab report deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting lab report: {str(e)}', 'danger')
    finally:
        cursor.close()
        conn.close()
    
    return redirect(url_for('manage_lab_reports'))

# Billing Management Routes
@app.route('/billing')
@login_required
def manage_billing():
    if current_user.role not in ['Admin', 'Receptionist']:
        flash('Access denied. Insufficient permissions.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT b.*, p.name as patient_name, d.name as doctor_name, a.date_time
        FROM Billing b
        JOIN Appointments a ON b.appointment_id = a.appointment_id
        JOIN Patients p ON a.patient_id = p.patient_id
        JOIN Doctors d ON a.doctor_id = d.doctor_id
        ORDER BY b.bill_date DESC
    ''')
    
    bills = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('billing.html', bills=bills)

@app.route('/add_bill', methods=['GET', 'POST'])
@login_required
def add_bill():
    if current_user.role not in ['Admin', 'Receptionist']:
        flash('Access denied. Insufficient permissions.', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        appointment_id = request.form['appointment_id']
        amount = request.form['amount']
        status = request.form['status']
        payment_method = request.form.get('payment_method', None)
        payment_date = request.form.get('payment_date', None)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO Billing (patient_id, appointment_id, amount, status, payment_method, payment_date)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (patient_id, appointment_id, amount, status, payment_method, payment_date))
            conn.commit()
            flash('Bill added successfully!', 'success')
            return redirect(url_for('manage_billing'))
        except Exception as e:
            print(f"Error adding bill: {str(e)}")
            flash('Error adding bill.', 'error')
        finally:
            cursor.close()
            conn.close()
    
    # Get list of patients and appointments for the form
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM Patients ORDER BY name')
    patients = cursor.fetchall()
    
    cursor.execute('''
        SELECT a.*, p.name as patient_name, d.name as doctor_name
        FROM Appointments a
        JOIN Patients p ON a.patient_id = p.patient_id
        JOIN Doctors d ON a.doctor_id = d.doctor_id
        ORDER BY a.date_time DESC
    ''')
    appointments = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('add_billing.html', patients=patients, appointments=appointments)

@app.route('/edit_bill/<int:bill_id>', methods=['GET', 'POST'])
@login_required
def edit_bill(bill_id):
    if current_user.role not in ['Admin', 'Receptionist']:
        flash('Access denied. Insufficient permissions.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        appointment_id = request.form['appointment_id']
        amount = request.form['amount']
        status = request.form['status']
        payment_method = request.form.get('payment_method', None)
        payment_date = request.form.get('payment_date', None)
        
        try:
            cursor.execute('''
                UPDATE Billing 
                SET patient_id = ?, appointment_id = ?, amount = ?, status = ?, payment_method = ?, payment_date = ?
                WHERE bill_id = ?
            ''', (patient_id, appointment_id, amount, status, payment_method, payment_date, bill_id))
            conn.commit()
            flash('Bill updated successfully!', 'success')
            return redirect(url_for('manage_billing'))
        except Exception as e:
            print(f"Error updating bill: {str(e)}")
            flash('Error updating bill.', 'error')
        finally:
            cursor.close()
            conn.close()
    
    cursor.execute('''
        SELECT b.*, p.name as patient_name
        FROM Billing b
        JOIN Patients p ON b.patient_id = p.patient_id
        WHERE b.bill_id = ?
    ''', (bill_id,))
    bill = cursor.fetchone()
    
    if not bill:
        flash('Bill not found.', 'error')
        return redirect(url_for('manage_billing'))
    
    cursor.execute('SELECT * FROM Patients ORDER BY name')
    patients = cursor.fetchall()
    cursor.execute('SELECT * FROM Appointments ORDER BY date_time DESC')
    appointments = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('edit_bill.html', bill=bill, patients=patients, appointments=appointments)

@app.route('/delete_bill/<int:bill_id>')
@login_required
def delete_bill(bill_id):
    if current_user.role not in ['Admin']:
        flash('Access denied. Insufficient permissions.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('DELETE FROM Billing WHERE bill_id = ?', (bill_id,))
        conn.commit()
        flash('Bill deleted successfully!', 'success')
    except Exception as e:
        print(f"Error deleting bill: {str(e)}")
        flash('Error deleting bill.', 'error')
    finally:
        cursor.close()
        conn.close()
    
    return redirect(url_for('manage_billing'))

# User Management Routes
@app.route('/users')
@login_required
def manage_users():
    if not current_user.is_admin():
        flash('Access denied. Only administrators can manage users.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Users ORDER BY username')
    users = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('manage_users.html', users=users)

@app.route('/add_user', methods=['GET', 'POST'])
@login_required
def add_user():
    if not current_user.is_admin():
        flash('Access denied. Only administrators can add users.', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO Users (username, password_hash, role)
                VALUES (?, ?, ?)
            ''', (username, generate_password_hash(password), role))
            conn.commit()
            flash('User added successfully!', 'success')
            return redirect(url_for('manage_users'))
        except Exception as e:
            print(f"Error adding user: {str(e)}")
            flash('Error adding user.', 'error')
        finally:
            cursor.close()
            conn.close()
    
    return render_template('add_user.html')

@app.route('/edit_user/<int:user_id>', methods=['GET', 'POST'])
@login_required
def edit_user(user_id):
    if not current_user.is_admin():
        flash('Access denied. Only administrators can edit users.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        username = request.form['username']
        role = request.form['role']
        password = request.form.get('password')
        
        try:
            if password:
                cursor.execute('''
                    UPDATE Users 
                    SET username = ?, password_hash = ?, role = ?
                    WHERE user_id = ?
                ''', (username, generate_password_hash(password), role, user_id))
            else:
                cursor.execute('''
                    UPDATE Users 
                    SET username = ?, role = ?
                    WHERE user_id = ?
                ''', (username, role, user_id))
            conn.commit()
            flash('User updated successfully!', 'success')
            return redirect(url_for('manage_users'))
        except Exception as e:
            print(f"Error updating user: {str(e)}")
            flash('Error updating user.', 'error')
        finally:
            cursor.close()
            conn.close()
    
    cursor.execute('SELECT * FROM Users WHERE user_id = ?', (user_id,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('manage_users'))
    
    return render_template('edit_user.html', user=user)

@app.route('/delete_user/<int:user_id>')
@login_required
def delete_user(user_id):
    if not current_user.is_admin():
        flash('Access denied. Only administrators can delete users.', 'error')
        return redirect(url_for('dashboard'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('DELETE FROM Users WHERE user_id = ?', (user_id,))
        conn.commit()
        flash('User deleted successfully!', 'success')
    except Exception as e:
        print(f"Error deleting user: {str(e)}")
        flash('Error deleting user.', 'error')
    finally:
        cursor.close()
        conn.close()
    
    return redirect(url_for('manage_users'))

def create_default_users():
    default_users = [
        {'username': 'admin', 'password': 'admin123', 'role': 'Admin'},
        {'username': 'doctor', 'password': 'doctor123', 'role': 'Doctor'},
        {'username': 'receptionist', 'password': 'reception123', 'role': 'Receptionist'},
        {'username': 'nurse', 'password': 'nurse123', 'role': 'Nurse'},
        {'username': 'labtech', 'password': 'labtech123', 'role': 'Lab Technician'}
    ]
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    for user_data in default_users:
        try:
            # Check if user already exists
            cursor.execute('SELECT user_id FROM Users WHERE username = ?', (user_data['username'],))
            if not cursor.fetchone():
                # Create new user
                cursor.execute('''
                    INSERT INTO Users (username, password_hash, role)
                    VALUES (?, ?, ?)
                ''', (
                    user_data['username'],
                    generate_password_hash(user_data['password']),
                    user_data['role']
                ))
                conn.commit()
                print(f"Created {user_data['role']} user: {user_data['username']}")
        except Exception as e:
            print(f"Error creating user {user_data['username']}: {str(e)}")
    
    cursor.close()
    conn.close()

def create_tables():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Create LabReports table if it doesn't exist
        cursor.execute('''
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'LabReports')
            BEGIN
                CREATE TABLE LabReports (
                    report_id INT IDENTITY(1,1) PRIMARY KEY,
                    patient_id INT NOT NULL,
                    doctor_id INT NOT NULL,
                    test_name NVARCHAR(100) NOT NULL,
                    results NVARCHAR(MAX),
                    status NVARCHAR(20) NOT NULL,
                    date DATETIME NOT NULL,
                    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
                    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id)
                )
            END
        ''')
        conn.commit()
        print("LabReports table created or already exists")
    except Exception as e:
        print(f"Error creating LabReports table: {str(e)}")
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    create_tables()
    create_default_users()
    app.run(debug=True, port=5001) 